package metier;

import java.util.Date;
import java.util.List;

import metier.entities.Article;
import metier.entities.Categorie;

public interface ICatalogueMetier {
       //public Categorie addCategorie();
	   public abstract Categorie addCategorie(Categorie c);
	   public abstract Article addArticle(Article a);
       public abstract List<Article> listArticle();
       public abstract List<Article> articlesParMC(String mc);
       public abstract List<Article> articlesParCat(Long idCat);
       public abstract Categorie updateCategorie(Categorie c);
       public abstract Article updateArticle(Article a);
       public abstract boolean deleteArticle(Long idart);
       public abstract Categorie getCategorie(Long idCat);
       public abstract Article getArticle(Long idart);
       
       
       
       
       
}
