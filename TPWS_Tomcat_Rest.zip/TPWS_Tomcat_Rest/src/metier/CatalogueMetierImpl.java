package metier;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import metier.entities.Article;
import metier.entities.Categorie;

public class CatalogueMetierImpl implements ICatalogueMetier {
	private Map<Long,Categorie> categories = new HashMap<Long,Categorie>();
	private Map<Long,Article> articles = new HashMap<Long,Article>();

	@Override
	public List<Article> listArticle() {
		// TODO Auto-generated method stub
		return new ArrayList<Article>(articles.values());
	}

	@Override
	public List<Article> articlesParMC(String mc) {
		// TODO Auto-generated method stub
		List<Article> articl = new ArrayList<Article>();
		for(Article p:articles.values()) {
			if( p.getTitre().contains(mc)) {
				articl.add(p);
			}
		}
		return articl;
	}

	@Override
	public List<Article> articlesParCat(Long idCat) {
		// TODO Auto-generated method stub
		List<Article> articl = new ArrayList<Article>();
		for(Article p:articles.values()) {
			if(p.getCategorie().getIdCategorie().equals(idCat)) {
				articl.add(p);
			}
			
			
		}
		return articl;
	}

	@Override
	public Categorie addCategorie(Categorie c) {
		// TODO Auto-generated method stub
		categories.put(c.getIdCategorie(),c);
		return c;
	}

	@Override
	public Article addArticle(Article a) {
		// TODO Auto-generated method stub
		a.setCategorie(getCategorie(a.getCategorie().getIdCategorie()));
		articles.put(a.getIdArticle(),a);
		return a;
	}

	@Override
	public Categorie updateCategorie(Categorie c) {
		// TODO Auto-generated method stub
		categories.put(c.getIdCategorie(), c);
		return c;
	}

	@Override
	public Article  updateArticle(Article a) {
		// TODO Auto-generated method stub		
		articles.put(a.getIdArticle(), a);
		return a;
	}

	@Override
	public boolean deleteArticle(Long idart) {
		// TODO Auto-generated method stub
		if(articles.get(idart)!=null) {
			articles.remove(idart);
			return true;
		}else throw new RuntimeException("Article introuvable");
		
	}

	@Override
	public Categorie getCategorie(Long idCat) {		
		// TODO Auto-generated method stub
		return categories.get(idCat);
	}

	@Override
	public Article getArticle(Long idart) {
		// TODO Auto-generated method stub
		return articles.get(idart);
	}
	
	public void initialiserCatalogue() {
         addCategorie(new Categorie(1L,"sport"));
         addCategorie(new Categorie(2L,"Sante"));
         addCategorie(new Categorie(3L,"Education"));
         articles.put(1L,new Article(1L,"remier victoire du Sénégal","orem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",new Date(),new Date(),getCategorie(1L)));
         articles.put(2L,new Article(2L,"Election en Mauritanie","Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",new Date(),new Date(),getCategorie(4L)));
		 articles.put(3L,new Article(3L,"Début de la CAN","Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",new Date(),new Date(),getCategorie(1L)));
		 articles.put(4L,new Article(4L,"Pétrole au Sénégal","Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",new Date(),new Date(),getCategorie(4L)));
		 articles.put(4L,new Article(5L,"Inauguration d'un ENO à l'UVS","Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",new Date(),new Date(),getCategorie(3L)));

		}
}

