package metier.entities;

import java.io.Serializable;

public class Categorie implements Serializable {
	private long idCategorie;
	private String nomCategorie;
	public Categorie() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Categorie(long idCategorie, String nomCategorie) {
		super();
		this.idCategorie = idCategorie;
		this.nomCategorie = nomCategorie;
	}
	public long getIdCategorie() {
		return idCategorie;
	}
	public void setIdCategorie(long idCategorie) {
		this.idCategorie = idCategorie;
	}
	public String getNomCategorie() {
		return nomCategorie;
	}
	public void setNomCategorie(String nomCategorie) {
		this.nomCategorie = nomCategorie;
	}
	

}
