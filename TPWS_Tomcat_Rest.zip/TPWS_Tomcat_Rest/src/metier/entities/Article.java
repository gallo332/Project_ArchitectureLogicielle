package metier.entities;

import java.io.Serializable;
import java.util.Date;

public class Article implements Serializable {
	private long idArticle;
	private String titre;
	private String contenu;
	private Date dateDeCreation;
	private Date dateDeModification;
	private Categorie categorie;
	public Article() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Article(long idArticle, String titre, String contenu, Date dateDeCreation, Date dateDeModification,
			Categorie categorie) {
		super();
		this.idArticle = idArticle;
		this.titre = titre;
		this.contenu = contenu;
		this.dateDeCreation = dateDeCreation;
		this.dateDeModification = dateDeModification;
		this.categorie = categorie;
	}
	public long getIdArticle() {
		return idArticle;
	}
	public void setIdArticle(long idArticle) {
		this.idArticle = idArticle;
	}
	public String getTitre() {
		return titre;
	}
	public void setTitre(String titre) {
		this.titre = titre;
	}
	public String getContenu() {
		return contenu;
	}
	public void setContenu(String contenu) {
		this.contenu = contenu;
	}
	public Date getDateDeCreation() {
		return dateDeCreation;
	}
	public void setDateDeCreation(Date dateDeCreation) {
		this.dateDeCreation = dateDeCreation;
	}
	public Date getDateDeModification() {
		return dateDeModification;
	}
	public void setDateDeModification(Date dateDeModification) {
		this.dateDeModification = dateDeModification;
	}
	public Categorie getCategorie() {
		return categorie;
	}
	public void setCategorie(Categorie categorie) {
		this.categorie = categorie;
	}
	
	
}
