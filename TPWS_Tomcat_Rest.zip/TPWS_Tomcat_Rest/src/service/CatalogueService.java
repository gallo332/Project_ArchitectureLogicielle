package service;

import java.util.List;

import metier.CatalogueMetierImpl;
import metier.entities.Article;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.util.List;
// nom web service rest
@Path("/catalogue")
public class CatalogueService {
	private CatalogueMetierImpl metier;
	// constructeur
	public CatalogueService() {
		metier = new CatalogueMetierImpl();
		metier.initialiserCatalogue();

}
	@Path("/articles")
    @GET
    @Produces({MediaType.APPLICATION_JSON+"; charset=utf-8"})
	public List<Article> consulterArticles(){
		return metier.listArticle();
	}
	
	@Path("/articles")
    @GET
    @Produces({MediaType.APPLICATION_JSON+"; charset=utf-8"})
	public List<Article> articlesParCategorie(@PathParam(value= "idCat")Long idCat){
		return metier.articlesParCat(idCat);
	}
	// MC = Mot-Cles
	@Path("/categories/articles/{idCat}")
    @GET
    @Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	public List<Article> articlesParMC(@QueryParam(value= "mc")String mc){
		return metier.articlesParMC(mc);
	}
}
