package metier;

import java.util.List;
import javax.ejb.Stateless;
import javax.ejb.EntityManager;
import javax.persitence.PersistenceContext;
import javax.persitence.*;
import metier.entities.Article;
@Stateless(name="CAT")

public class CatalogueMetier implements ICatalogueRemote, ICatalogueLocal {
	//unite de persistence pour injection
	@PersistenceContext(unitName="UP_CAT")
	private EntityManager em;

	@Override
	public List<Article> listArticle() {
		// TODO Auto-generated method stub
		Query req=em.createQuery("select p from Produit p");
		return req.getResultList() ;
	}

	@Override
	public List<Article> articlesParMC(String mc) {
		// TODO Auto-generated method stub
		Query req=em.createQuery("select p from Article p where p.nomArticle like:x");
		req.setParameter("x","%"+mc+"%");
		return req.getResultList() ;
	}

	@Override
	public List<Article> articlesParCat(Long idCat) {
		// TODO Auto-generated method stub
		Query req=em.createQuery("select p from Produit p where p.idCategorie = x");
		req.setParameter("x","%"+idCat+"%");
		return req.getResultList() ;
	}

}
