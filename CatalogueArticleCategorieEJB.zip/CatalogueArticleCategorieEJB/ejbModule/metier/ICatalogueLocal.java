/**
 * 
 */
package metier;

/**
 * @author LENOVO
 *
 */
import java.util.List;

import metier.entities.Article;

public interface ICatalogueLocal {
	 public abstract List<Article> listArticle();
     public abstract List<Article> articlesParMC(String mc);
     public abstract List<Article> articlesParCat(Long idCat);


}
