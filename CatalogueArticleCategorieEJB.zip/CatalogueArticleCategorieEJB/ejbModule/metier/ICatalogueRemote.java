package metier;
import java.util.List;

import javax.ejb.Remote;

import metier.entities.Article;
@Remote

public interface ICatalogueRemote {
	 public abstract List<Article> listArticle();
     public abstract List<Article> articlesParMC(String mc);
     public abstract List<Article> articlesParCat(Long idCat);

}
