package service;
import javax.ejb.EJB;
import javax.jws.WebMethod;
import javax.jws.WebService;
import metier.IUtilisateurLocal;
import metier.List;
import metier.Query;
import metier.entities.Utilisateur;

@WebService
public class UtilisateurService {
	@EJB
	private IUtilisateurLocal metier;
	 @WebMethod
   	public List<Utilisateur> listUtilisateur() {
		return metier.listUtilisateur();
	}

	public Utilisateur addUtilisateur(Utilisateur c) {
		return metier.addUtilisateur(c);
	}
    @WebMethod
	public void updateUtilisateur(Utilisateur u) {
		metier.updateUtilisateur(u);
	}
    @WebMethod
	public void supprimerUtilisateur(@WebParam(name="id")int id) {
		metier.supprimerUtilisateur(id);
	}
    @WebMethod
	public Utilisateur getUtilisateur(@WebParam(name="id")int id) {
		metier.getUtilisateur(id);
	}
    @WebMethod
	public void updateToken(Utilisateur c,@WebParam(name="id")int id, String token) {
		metier.updateToken(c,id,token);
			
	}
}
