package service;

import java.util.List;
import metier.entities.Article;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.util.List;
import metier.ICatalogueLocal;
import metier.entities.Article;

//nom web service rest
@Path("/catalogue")
public class ArticleCategorieService {
	private ICatalogueLocal metier;
    
	@Path("/articles")
    @GET
    @Produces({MediaType.APPLICATION_JSON+"; charset=utf-8"})
	public List<Article> listArticle() {
		return metier.listArticle();
	}
    
	@Path("/articles/{mc}")
    @GET
    @Produces({MediaType.APPLICATION_JSON+"; charset=utf-8"})
	public List<Article> articlesParMC(String mc) {
		return metier.articlesParMC(mc);
	}
    
	@Path("/articles/{idCat}")
    @GET
    @Produces({MediaType.APPLICATION_JSON+"; charset=utf-8"})
	public List<Article> articlesParCat(Long idCat) {
		return metier.articlesParCat(idCat);
	}

}
