package metier;

import java.io.Serializable;
import javax.persitence.Entity;
import javax.persitence.Table;
import javax.persitence.*;
@entity
@Table(name="Produit")
public class Categorie implements Serializable {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@column(name="ID_PRODUIT")
	private long idCategorie;
	private String nomCategorie;
	public Categorie() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Categorie( String nomCategorie) {
		super();
		this.nomCategorie = nomCategorie;
	}
	public long getIdCategorie() {
		return idCategorie;
	}
	public void setIdCategorie(long idCategorie) {
		this.idCategorie = idCategorie;
	}
	public String getNomCategorie() {
		return nomCategorie;
	}
	public void setNomCategorie(String nomCategorie) {
		this.nomCategorie = nomCategorie;
	}
	

}
