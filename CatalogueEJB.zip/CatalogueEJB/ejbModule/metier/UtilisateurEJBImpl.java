package metier;

import java.util.List;
import java.util.jar.Pack200;

import metier.entities.Utilisateur;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.Query;
import javax.ejb.EntityManager;
import javax.persitence.PersistenceContext;
import javax.persitence.*;
import metier.Article;
@Stateless(name="UT")

public class UtilisateurEJBImpl implements UtilisateurRemote, IUtilisateurLocal {
	//unite de persistence pour injection
		@PersistenceContext(unitName="UP_UT")
		private EntityManager em;

	@Override
	public List<Utilisateur> listUtilisateur() {
		// TODO Auto-generated method stub
		Query req=em.createQuery("select c from Utilisateur c");
		return  req.getResultList();
	}

	@Override
	public Utilisateur addUtilisateur(Utilisateur c) {
		// TODO Auto-generated method stub
		em.persist(c);
	}

	@Override
	public void supprimerUtilisateur(int id) {
		// TODO Auto-generated method stub
		Utilisateur u= em.find(Utilisateur.class,id);
		if(u==null) throw new RuntimeException("Utilisateur introuvable");
		em.remove(u);
		
	}

	@Override
	public void updateUtilisateur(Utilisateur u) {
		// TODO Auto-generated method stub
		Utilisateur u1= em.find(Utilisateur.class,u.getId());
		u1.setFirstname(u.getFirstname());
		u1.setLastname(u.getLastname());
		u1.setPassword(u.getPassword());
		u1.setRole(u.getRole());
		//u1.setToken(u.getToken());
		u1.setUsername(u.getUsername());
		u1.setEmail(u.getEmail());
		em.persist(u1);
		
	}

	@Override
	public Utilisateur getUtilisateur(int id) {
		// TODO Auto-generated method stub
		Utilisateur u= em.find(Utilisateur.class,id);
		if(u==null) throw new RuntimeException("Utilisateur introuvable");
		return u;
	}

	@Override
	public void updateToken(Utilisateur c,int id, String token) {
		// TODO Auto-generated method stub
		Query req=em.createQuery("update Utilisateur c set token=? where id=?");
		//Utilisateur u1= em.find(Utilisateur.class,u.getId());
		req.setString(1,token);
		req.setInt(2,id);
		
		
		
	}

}
