package metier;
import java.util.List;

import javax.ejb.Remote

import metier.entities.Utilisateur;
@Remote


public interface UtilisateurRemote {
	public abstract List<Utilisateur> listUtilisateur();
    public abstract Utilisateur addUtilisateur(Utilisateur c);
    public abstract void supprimerUtilisateur(Long id);
    public abstract void updateUtilisateur(Utilisateur u );
    public abstract Utilisateur getUtilisateur(int id);
    public abstract void updateToken(Utilisateur c,Long id,String token );
   
    


}
