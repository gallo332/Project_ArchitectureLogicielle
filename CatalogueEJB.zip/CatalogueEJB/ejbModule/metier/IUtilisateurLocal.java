package metier;
import java.util.List;

import javax.ejb.Local;

import metier.entities.Utilisateur;
@Local


public interface IUtilisateurLocal {
	public abstract List<Utilisateur> listUtilisateur();
    public abstract Utilisateur addUtilisateur(Utilisateur c);
    public abstract void supprimerUtilisateur(Long id);
    public abstract void updateUtilisateur(Utilisateur u );
    public abstract Utilisateur getUtilisateur(Long id);
    public abstract void updateToken(Utilisateur c,int Long,String token );
   
    
    
    


}