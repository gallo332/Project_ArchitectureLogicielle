package serveurWS;
import javax.xml.ws.Endpoint;

import java.sql.SQLException;

import javax.xml.ws.Endpoint;

import metier.IUtilisateurMetier;
import ws.UtilisateurService;

public class ServeurJAX_WS implements IUtilisateurMetier {
public static void main(String[] args) {
		
		try {
			Endpoint.publish(URL, new UtilisateurService());
			System.out.println(URL);
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}


}
