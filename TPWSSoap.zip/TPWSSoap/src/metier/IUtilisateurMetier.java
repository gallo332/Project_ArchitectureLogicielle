package metier;

public interface IUtilisateurMetier {
	static final String URL = "http://localhost:8888/WebService";
	static final String DRIVER = "jdbc:mysql";
	static final String HOST = "localhost";
	static final String DBNAME =  "mglsi_news";
	static final String PORT = "3306";
	static final String USERNAME = "root";
	static final String PASSWORD = "";

}
