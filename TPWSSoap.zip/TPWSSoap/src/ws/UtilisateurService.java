package ws;

import java.sql.SQLException;
import java.util.ArrayList;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

import dao.Dao;
import domaine.Utilisateur;

@WebService(serviceName = "utilisateurWS")

public class UtilisateurService {
	private Dao dao;

	/**
	 * @param dao
	 * @throws SQLException 
	 */
	public UtilisateurService() throws SQLException {
		dao = new  Dao();
	}
	@WebMethod
	public Utilisateur login(String username, String password, String token) {
		try {
			return dao.login(username, password);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@WebMethod
	public boolean modifierToken(@WebParam(name = "id")int id, String token) {
		try {
			return dao.modifierToken(id, token);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
	@WebMethod
	public ArrayList<Utilisateur> listerUtilisateurs() {
		
		try {
			return dao.listerUtilisateurs();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	@WebMethod
	public Utilisateur listerUtilisateur(@WebParam(name = "id")int id) {
		
		try {
			return dao.listerUtilisateur(id);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	@WebMethod
	public boolean ajouterUtilisateur(Utilisateur u) {
		try {
			return dao.ajouterUtilisateur(u);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
	@WebMethod
	public boolean modifierUtilisateur(Utilisateur u) {
		try {
			return dao.modifierUtilisateur(u);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
	@WebMethod
	public boolean supprimerUtilisateur(@WebParam(name = "id")int id) {
		
		try {
			return dao.supprimerUtilisateur(id);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

}
