import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import metier.UtilisateurRemote;
import metier.entities.Utilisateur;

public class ClientRemote {
	public static void main(String[] args) throws NamingException {

		Context ctx = new InitialContext();
		String appName="";
		String moduleName="CatalogueEJB";
		String beanName="UT";
		String remoteInterface="metier.UtilisateurRemote";
		String name="ejb"+appName+"/"+moduleName+"/"+beanName+"|"+remoteInterface;
		UtilisateurRemote proxy= (UtilisateurRemote) ctx.lookup(name);
		proxy.addUtilisateur(new Utilisateur(1,"diallo","mamadou","diallomamadou@esp.sn","DIALLO332","dial332","admin","Dia3F"));
		proxy.addUtilisateur(new Utilisateur(2,"ba","hamidou","bahamidou@esp.sn","BA332","bal332","user","BaF6"));
		proxy.getUtilisateur(1);
		proxy.listUtilisateur();
		
		
		
}
}
